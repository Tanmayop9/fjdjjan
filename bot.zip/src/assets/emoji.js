export const emoji = {
    // blacklist
    bl: '<:neroxinfo:1435499789264617484>',
    // general
    check: '<:neroxinfo:1435499789264617484>',
    cross: '<:neroxinfo:1435499789264617484>',
    info: '<:neroxinfo:1435499789264617484>',
    info1: '<:neroxinfo:1435499789264617484>',
    timer: '<:neroxinfo:1435499789264617484>',
    warn: '<:neroxinfo:1435499789264617484>',
    // player controls
    previous: '<:neroxinfo:1435499789264617484>',
    pause: '<:neroxinfo:1435499789264617484>',
    resume: '<:neroxinfo:1435499789264617484>',
    next: '<:neroxinfo:1435499789264617484>',
    stop: '<:neroxinfo:1435499789264617484>',
    autoplay: '<:neroxinfo:1435499789264617484>',
    // premium
    premium: '<:neroxinfo:1435499789264617484>',
    prem: '<:neroxinfo:1435499789264617484>',
};
/**@codeStyle - https://google.github.io/styleguide/tsguide.html */